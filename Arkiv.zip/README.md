# Eksamensprosjekt 

## MAA Invest - aksjeportefølje applikasjon

Dette repository inneholder koden vår til eksamensprosjektet i programmering.

## Forutsetninger, som må lastes ned før man kjører npm scriptet

1. npm install
2. motcha
3. Chai-http
4. yahoo-finance2
5. mssql
6. Express
7. ejs
8. chai
9. npm test

## Kjøring av prosjektet

prosjektet kan startes med en egendefinert npm-script, følg disse trinnene:

1. **Åpne terminalen**  Sørg for at din terminal er åpen og at du befinner deg i prosjekt mappen

2. **Kjør npm: scriptet** Følgende kommando installerer nødvendigheter og starter serveren 

    ```bash
    npm run eksamen
    ```
 



